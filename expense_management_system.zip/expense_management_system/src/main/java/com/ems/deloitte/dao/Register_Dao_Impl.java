package com.ems.deloitte.dao;
import java.sql.Connection;

import java.sql.PreparedStatement;

import java.sql.SQLException;

 

import com.ems.deloitte.model.User;

import com.ems.deloitte.util.DBConnection;

 

 

 //User Registration Implementation 

public class Register_Dao_Impl implements Register_Dao{

 

 

 

 

 

		@Override

		public int addusers(User u) throws SQLException {

			Connection con=DBConnection.getDBConnection();

			PreparedStatement pst=con.prepareStatement("insert into user_details values(?,?,?,?,?,?,?)");

			
			pst.setString(1, u.getUid());
			
			pst.setString(2, u.getUname());

			pst.setString(3, u.getFname());

			pst.setString(4, u.getLname());

			pst.setString(5, u.getContact());

			pst.setString(6, u.getEmail());

			pst.setString(7, u.getUpass());

 

			return pst.executeUpdate();

		}
}

 

 



 

		