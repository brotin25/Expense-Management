package com.ems.deloitte.model;

//Class of User
public class User {
	String uid,uname,fname,lname,contact,email,upass;
	public User(String uid, String uname, String fname, String lname, String contact, String email, String upass) {
		super();
		this.uid=uid;
		this.uname=uname;
		this.fname=fname;
		this.lname=lname;
		this.contact=contact;
		this.email=email;
		this.upass=upass;
	}
	
	//Getter Setter 

	public String getUid() {
		return uid;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}

	public String getUname() {
		return uname;
	}

	public void setUname(String uname) {
		this.uname = uname;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getUpass() {
		return upass;
	}

	public void setUpass(String upass) {
		this.upass = upass;
	}

}
