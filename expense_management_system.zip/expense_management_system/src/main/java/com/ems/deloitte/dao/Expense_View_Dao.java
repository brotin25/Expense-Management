package com.ems.deloitte.dao;

 

import java.sql.SQLException;
import java.util.List;
import com.ems.deloitte.model.ExpenseDetails;

 

public interface Expense_View_Dao {
        public int addExpense(ExpenseDetails exp)throws SQLException;
        public int deleteExpense(int expenseid)throws SQLException;
        public List<ExpenseDetails> getAllExpenses(String user_id) throws SQLException;
}	