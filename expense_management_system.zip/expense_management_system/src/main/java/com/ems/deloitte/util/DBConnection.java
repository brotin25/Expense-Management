package com.ems.deloitte.util;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {
	
	public static Connection getDBConnection() {
		Connection con = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.
					getConnection("jdbc:mysql://localhost:3306/deloitte_ems", "root", "Gogol@18");

		}catch(Exception e) {
			System.out.println(e);
		}
		return con;
	}
}
