package com.ems.deloitte.util;

public class UserIdGenerator {
	public static String generateRandomUserId(String username) {
		String randomUserId = "";
		for(int i=0; i<4; i++) {
			randomUserId = randomUserId + (int)(Math.random()*10);
		}
		return username.toLowerCase()+randomUserId+"@";
	}
}

