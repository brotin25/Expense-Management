package com.ems.deloitte.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

 

 

import com.ems.deloitte.model.ExpenseDetails;
import com.ems.deloitte.util.DBConnection;

 
//Expense View Class

public class Expense_View_Dao_Impl implements Expense_View_Dao {



 
//Expense Add Method
    @Override
    public int addExpense(ExpenseDetails exp) throws SQLException {
    	Connection con = DBConnection.getDBConnection();

    	PreparedStatement pst = con.prepareStatement("INSERT INTO expense_details(user_id,expense_date,expense_type,expense_desc,expemse_amt) VALUES(?,?,?,?,?)");

    	//pst.setInt(1, exp.getExpenseId());

    	pst.setString(1, exp.getUserId());

    	pst.setDate(2, exp.getExpenseDate());

    	pst.setString(3, exp.getExpenseType());

    	pst.setString(4, exp.getExpenseDesc());

    	pst.setDouble(5, exp.getExpenseAmount());
    	
    	
    	 

    	return pst.executeUpdate();
 
    }

 

 
//Expense Delete Method
    @Override
    public int deleteExpense(int expenseid) throws SQLException {
        Connection con = DBConnection.getDBConnection();
        PreparedStatement pst = con.prepareStatement("DELETE FROM expense_details WHERE expense_id = ?");
        pst.setInt(1, expenseid);
        return pst.executeUpdate();
    }

 

 
//Expense Derails Method
    @Override
    public List<ExpenseDetails> getAllExpenses(String userid) throws SQLException  {
        List<ExpenseDetails> expenseList = new ArrayList<ExpenseDetails>();
        Connection con = DBConnection.getDBConnection();
        PreparedStatement pst = con.prepareStatement("select * from expense_details where user_id = ?;");
        pst.setString(1, userid);
        ResultSet rs= pst.executeQuery();
        while(rs.next()) {
            ExpenseDetails exp =new ExpenseDetails(rs.getInt(1),rs.getString(2),rs.getDate(3),rs.getString(4),rs.getString(5),rs.getDouble(6));
            expenseList.add(exp);
        }
        return expenseList;
    }

 

 

}
