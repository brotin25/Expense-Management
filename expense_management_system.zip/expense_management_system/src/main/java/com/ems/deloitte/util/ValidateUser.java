package com.ems.deloitte.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;


 

public class ValidateUser {
    public static int validateUserName(String username) {
        int count=1;

 

        try {

 

        Connection con=DBConnection.getDBConnection();

 

        PreparedStatement pst=con.prepareStatement("select * from USER_DETAILS where user_name=?");

 

        pst.setString(1, username);

 

        ResultSet rs= pst.executeQuery();

 

        while(rs.next()) {

 

        count=0;

 

        }

 

        System.out.println(count);

 

        }

 

        catch(Exception e)

 

        {

 

        System.out.println(e);

 

        }

 

        return count;

 

         

 

        }
}
