package com.ems.deloitte.model;
import java.sql.Date;

public class ExpenseDetails

{

		//model class is created only for the expenses....

	private int expenseId;

	private String userId;

	private Date expenseDate;

	private String expenseType;

	private String expenseDesc;

	private Double expenseAmount;

 

 

	public ExpenseDetails(int expenseId, String userId, Date expenseDate, String expenseType, String expenseDesc,Double expenseAmount) {

 

		this.expenseId = expenseId;
		this.userId = userId;
		this.expenseDate = expenseDate;
		this.expenseType = expenseType;
		this.expenseDesc = expenseDesc;
		this.expenseAmount = expenseAmount;
	}

//GETTER AND SETTER

		public int getExpenseId() {
			return expenseId;
		}
		public void setExpenseId(int expenseId) {
			this.expenseId = expenseId;
			}
		public String getUserId() {
			return userId;
			}
		public void setUserId(String userId) {
			this.userId = userId;
			}
		public Date getExpenseDate() {
			return expenseDate;
			}
		public void setExpenseDate(Date expenseDate) {
			this.expenseDate = expenseDate;
			}

 

		public String getExpenseType() {

 

			return expenseType;

 

		}

 

		public void setExpenseType(String expenseType) {

 

			this.expenseType = expenseType;

 

		}

 

		public String getExpenseDesc() {

 

			return expenseDesc;

 

		}

 

		public void setExpenseDesc(String expenseDesc) {

 

			this.expenseDesc = expenseDesc;

 

		}

 

		public Double getExpenseAmount() {

 

			return expenseAmount;

 

		}

 

		public void setExpenseAmount(Double expenseAmount) {

 

			this.expenseAmount = expenseAmount;

 

		}

 

}