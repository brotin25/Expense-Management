package com.ems.deloitte.controller;
import com.ems.deloitte.util.DBConnection;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Login_Servlet
 */
@WebServlet("/Login_Servlet")
public class Login_Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	 

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        String username = request.getParameter("uname");
        String password = request.getParameter("upass");
        
        try {
        	Class.forName("com.mysql.cj.jdbc.Driver");
        	if(validate_user(username,password)) {
        			Connection con = DBConnection.getDBConnection();
        			PreparedStatement pst = con.prepareStatement("select * from user_details WHERE user_name=? AND password=?");
        			pst.setString(1,username);
        			pst.setString(2, password);
        			ResultSet rs = pst.executeQuery();
            
            
            
        			if(rs.next()) {
        				
        				HttpSession session = request.getSession();
        				
        				String userid = rs.getString(1);
        				System.out.println(userid);
        				
        				session.setAttribute("userid", userid);

        				RequestDispatcher rd = request.getRequestDispatcher("ExpenseView");

        				rd.forward(request, response);

        					 
        			}
        	}
            else {
                out.print("<center><h3 style='color: red'>Please Give Proper Username and Password</h3></center>");
                RequestDispatcher rd = request.getRequestDispatcher("Login.html");
                rd.include(request, response);
            }
            
        	}catch(Exception e) {
        		e.printStackTrace();
            }
    }

        private static boolean validate_user(String username,String password) {

        	 

        	boolean status = false;

        	try {

        	 

        	Connection con = DBConnection.getDBConnection();

        	PreparedStatement ps = con.prepareStatement("select * from user_details where user_name=? and password=?;");

        	ps.setString(1, username);

        	ps.setString(2, password);

        	ResultSet rs = ps.executeQuery();

        	status = rs.next();

        	}

        	catch(Exception e){System.out.println(e);}

        	 

        	return status;

        	

        	 

        	

    }
 

}
