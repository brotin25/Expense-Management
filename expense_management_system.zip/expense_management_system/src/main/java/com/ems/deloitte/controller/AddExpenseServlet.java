package com.ems.deloitte.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.sql.SQLException;
import com.ems.deloitte.dao.Expense_View_Dao;
import com.ems.deloitte.dao.Expense_View_Dao_Impl;
import com.ems.deloitte.model.ExpenseDetails;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**

* Servlet implementation class AddExpense

*/

@WebServlet("/AddExpenseServlet")

//Adding Expense Based on userid

public class AddExpenseServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		Expense_View_Dao expDao = new Expense_View_Dao_Impl();
		HttpSession session=request.getSession();
		
		String userId=(String)session.getAttribute("userid");

		String expenseType=request.getParameter("etype");

		String expenseDesc=request.getParameter("edesc");

		Date expenseDate=Date.valueOf(request.getParameter("edate"));

		Double expenseAmount=Double.parseDouble(request.getParameter("eamount"));



		
		ExpenseDetails expense=new ExpenseDetails(0, userId, expenseDate, expenseType, expenseDesc, expenseAmount);

		try {

			int count =expDao.addExpense(expense);
 
			if(count>0)

			{

				
				
				response.sendRedirect("ExpenseView");
			}

			else

			{

				out.print("<center><h5 style='color:red'>Add Failed!</h5></center> ");

				
				response.sendRedirect("ExpenseView");
			}

			} catch (SQLException e) {

 

				e.printStackTrace();

			}

 

 

	}

 

	}
