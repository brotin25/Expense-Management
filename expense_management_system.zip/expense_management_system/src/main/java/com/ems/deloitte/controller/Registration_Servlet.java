package com.ems.deloitte.controller;
import com.ems.deloitte.model.User;
import com.ems.deloitte.dao.*;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.ems.deloitte.util.DBConnection;
import com.ems.deloitte.util.UserIdGenerator;
import com.ems.deloitte.util.ValidateUser;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Registration_Servlet
 */
@WebServlet("/Registration_Servlet")
public class Registration_Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        String uname= request.getParameter("uname");
        if(ValidateUser.validateUserName(uname)!=0)
        {
        try {
        	
        	
            
            String fname = request.getParameter("fname");
            String lname = request.getParameter("lname");
            String contact = request.getParameter("contact");
            String email = request.getParameter("email");
            String upass = request.getParameter("upass");
            String uId = UserIdGenerator.generateRandomUserId(uname);
            
            
            User user = new User(uId,uname,fname,lname,contact,email,upass);
            
            Register_Dao registerDao=new Register_Dao_Impl();

            

            

            

            int count =registerDao.addusers(user);

            if(count>0) {

            out.print("<center><h2 style='color:green'>User Added Successfully!</h2></center> ");

            RequestDispatcher rd = request.getRequestDispatcher("Login.html");

            rd.include(request, response);

            }

            else

            {

            out.print("<center><h2 style='color:red'>Employee Add Failed!</h2></center> ");

            RequestDispatcher rd = request.getRequestDispatcher("register.html");

            rd.include(request, response);

            }
        
        }catch(Exception e) {

System.out.println(e);

        }
    }
        else {
            out.print("<h1>user exists</h1>");
            RequestDispatcher rd = request.getRequestDispatcher("Registration_Page.html");
            rd.include(request, response);
        }
}
}      
        
        
        
        
        
    

