package com.ems.deloitte.dao;
import java.sql.SQLException;



import com.ems.deloitte.model.User;

 
//User Add Interface
public interface Register_Dao {

public int addusers(User u) throws SQLException;

}