package com.ems.deloitte.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.io.PrintWriter;

import java.sql.SQLException;
import java.util.Collections;
import java.util.List;

 

import com.ems.deloitte.model.ExpenseDetails;

import com.ems.deloitte.dao.Expense_View_Dao_Impl;
import com.ems.deloitte.dao.Expense_View_Dao;


 

 //Expense View Sever implementation

@WebServlet("/ExpenseView")

public class ExpenseView extends HttpServlet {

	private static final long serialVersionUID = 1L;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	doPost(request, response);
    	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		response.setContentType("text/html");

		PrintWriter out = response.getWriter();

		Expense_View_Dao edDao = new Expense_View_Dao_Impl();
		HttpSession session = request.getSession();
		Double expAmtTotal=0.0;
		int count = 0;
		try {
			String userid = (String)session.getAttribute("userid");
			List<ExpenseDetails>expense_detailsList = edDao.getAllExpenses(userid);
			
			Collections.reverse(expense_detailsList);

			 
			out.print("<style>\r\n"
					+ "	.footer {\r\n"
					+ "  position: fixed;\r\n"
					+ "  left: 0;\r\n"
					+ "  bottom: 0;\r\n"
					+ "  width: 100%;\r\n"
					+ "  background-color: blue;\r\n"
					+ "  color: white;\r\n"
					+ "  text-align: center;\r\n"
					+ "}"
					+ "<div class=\"footer\">\r\n"
					+ "\r\n"
					+ "<center><h4>©Deloitte,All Rights Reserved</h4></center>\r\n"
					+ "\r\n"
					+ " \r\n"
					+ "\r\n"
					+ "</div>");
			out.print("<head>\r\n"	 

			+ "\r\n"

			+ "\r\n"

			 

			+ " <script type=\"text/javascript\">\r\n"

			 

			+ "\r\n"

			 

			+ " function preventBack() { window.history.forward(); }\r\n"

			 

			+ "\r\n"

			 

			+ " setTimeout(\"preventBack()\", 0);\r\n"

			 

			+ "\r\n"

			 

			+ " window.onunload = function () { null };\r\n"

			 

			+ "\r\n"

			 

			+ " </script>\r\n"

			 

			+ "\r\n"

			 

			+ "</head>");
 

			//out.print("<h5 style='text-align:right'>Welcome "+exp.getUserId()+" || <a href='login.html'>LogOut</a></h5>"); 
			
			
			out.print("<div id=\"header\">\r\n"
					+ "\r\n"
					+ "	<center><h1>Expense Management System</style></h1></center>\r\n"
					+ "\r\n"
					+ "	</div>\r\n"
					+ "\r\n"
					+ "	<div style=\"text-align:center; height: 460px; width: 500px;\r\n"
					+ "\r\n"
					+ "	margin-left: auto; margin-right: auto; color: black;\">\r\n");
			out.print("<body style=\"background-color:#2DCDDF;\">"
					+"<center>"
					+ "<h1>Expense Details</h1>"
					+ "<p style=\\\text-align:right;\\\">Welcome! "+userid+" ||<a href = 'LogoutServlet'> Logout</a></p>"
					+"<table border='1' align = 'center'>"
					+"<table border='1' align = 'center'>"
					+"<th>Expense ID</th><th>User Id</th><th>Date</th><th>Expense Description</th><th>Expense Type</th><th>Amount</th><th>Action</th>"
					);


			

			 
			 

			for(ExpenseDetails exp: expense_detailsList) {
				
			count++;
			expAmtTotal+=exp.getExpenseAmount();
			

			out.print("<tr>");

			out.print("<td>"+exp.getExpenseId()+"</td>"+"<td>"+exp.getUserId()+"</td>"+"<td>"+exp.getExpenseDate()+"</td>"+"<td>"+exp.getExpenseDesc()+"</td>"+"<td>" +exp.getExpenseType()+"</td>"+"<td>"+exp.getExpenseAmount()+"</td><td><a href = 'DeleteExpense?expense_id="+exp.getExpenseId()+"'>Delete</a> ");

			
			
			out.print("</tr>");
					
			
			
			if (count == 10) {
				break;
			}
			}
			out.print("<td></td><td></td><td></td><td></td><th>Total Amount"+"<td>"+expAmtTotal+"</td></th>");

					out.print("</table>");
					out.print("</center>");
					out.print("<center>");
					out.print("<br><a href='AddExpense.html'>AddExpense</a>");

					out.print("</center>");
					out.print("</body>");

				}catch(SQLException e) {

				e.printStackTrace();
	
}out.print("<style>\r\n"
		+ "        #footer {\r\n"
		+ "            position: fixed;\r\n"
		+ "            bottom: 0;\r\n"
		+ "            width: 50%;\r\n"
		+ "            /* Height of the footer*/\r\n"
		+ "            height: 40px;\r\n"
		+ "        }\r\n"
		+ "    </style>"
		+"<div id=\"footer\"><center><h4>©Deloitte,All Rights Reserved<h4></center>\r\n"
		+ "                </div>");

 

}

 

 

}
